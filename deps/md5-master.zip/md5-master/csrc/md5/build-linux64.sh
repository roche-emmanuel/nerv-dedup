P=linux64 C="-fPIC -include _memcpy.h" L="-s -static-libgcc" D=libmd5.so A=libmd5.a ./build.sh
