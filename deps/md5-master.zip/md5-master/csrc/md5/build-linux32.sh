P=linux32 L="-s -static-libgcc" D=libmd5.so A=libmd5.a ./build.sh
