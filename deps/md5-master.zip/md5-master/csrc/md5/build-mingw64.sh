P=mingw64 L="-s -static-libgcc" D=md5.dll A=md5.a ./build.sh
